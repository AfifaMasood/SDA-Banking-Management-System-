#include <iostream>
#include <vector>
#include <string>
#include <ctime>
using namespace std;
class Account;  
class Transaction;  
class Statement;  
class User 
{
private:
    int id;
    string username;
    string password;
    string name;
    string address;
    string contactDetails;
    User() {}
public:
    static User& getInstance()
    {
        static User instance;
        return instance;
    }
    void registerUser() 
    {
        cout << "User registered" << endl;
    }

    void login()
    {
        cout << "User logged in" << endl;
    }

    vector<Account> getAccounts()
    {
        vector<Account> accounts;
        // Populate accounts vector
        return accounts;
    }

    void applyForLoan() 
    {
        cout << "Loan application submitted" << endl;
    }

    vector<Transaction> viewTransactions() 
    {
        vector<Transaction> transactions;
        // Populate transactions vector
        return transactions;
    }

    void contactSupport()
    {
        cout << "Support contacted" << endl;
    }
    // Prevent copy construction and assignment
    User(User const&) = delete;
    void operator=(User const&) = delete;
};

class Admin 
{
private:
    int id;
    string username;
    string password;
    string name;
    string address;
    string contactDetails;
    Admin() {}
public:
    static Admin& getInstance() 
    {
        static Admin instance;
        return instance;
    }

    void login()
    {
        cout << "Admin logged in" << endl;
    }

    vector<User> getUsers() 
    {
        vector<User> users;
        // Populate users vector
        return users;
    }

    void generateReports()
    {
        cout << "Reports generated" << endl;
    }

    // Prevent copy construction and assignment
    Admin(Admin const&) = delete;
    void operator=(Admin const&) = delete;
};
class Report 
{
private:
    int reportId;
    string data;
    Report() {}
public:
    static Report& getInstance()
    {
        static Report instance;
        return instance;
    }
};
class Transaction 
{
private:
    int transactionId;
    string transactionType;
    double amount;
    time_t date;
    Transaction() {}
public:
    static Transaction& getInstance() 
    {
        static Transaction instance;
        return instance;
    }

    void performTransaction()
    {
        cout << "Transaction performed" << endl;
    }
};

class Account
{
private:
    string accountNumber;
    string accountType;
    double balance;
    Account() {}
public:
    // Static method to access the single instance of Account
    static Account& getInstance() 
    {
        static Account instance;
        return instance;
    }

    void deposit(double amount) 
    {
        balance += amount;
        cout << "Deposit successful" << endl;
    }

    void withdraw(double amount) 
    {
        if (balance >= amount)
        {
            balance -= amount;
            cout << "Withdrawal successful" << endl;
        }
        else
        {
            cout << "Insufficient funds" << endl;
        }
    }

    void transfer(double amount, Account& recipient) 
    {
        if (balance >= amount)
        {
            balance -= amount;
            recipient.balance += amount;
            cout << "Transfer successful" << endl;
        }
        else
        {
            cout << "Insufficient funds" << endl;
        }
    }

    vector<Transaction> getTransactions() 
    {
        vector<Transaction> transactions;
        // Populate transactions vector
        return transactions;
    }
};

class Loan 
{
private:
    string loanNumber;
    double amount;
    double interestRate;
    int repaymentPeriod;
    string status;
    Loan() {}
public:
    static Loan& getInstance() 
    {
        static Loan instance;
        return instance;
    }

    void apply() 
    {
        cout << "Loan application submitted" << endl;
    }

    void repay(double amount)
    {
        cout << "Loan repayment successful" << endl;
    }
};

class Statement 
{
private:
    int statementId;
    time_t startDate;
    time_t endDate;
    vector<Transaction> transactions;
    Statement() {}
public:
    static Statement& getInstance()
    {
        static Statement instance;
        return instance;
    }

    void generateStatement() 
    {
        cout << "Statement generated" << endl;
    }
};

class Support 
{
private:
    int ticketId;
    string issue;
    string status;
    Support() {}
public:
    static Support& getInstance()
    {
        static Support instance;
        return instance;
    }
    void contactSupport() 
    {
        cout << "Support contacted" << endl;
    }
};


int main() 
{
    
    User& user = User::getInstance();
    user.registerUser();
    user.login();

    Admin& admin = Admin::getInstance();
    admin.login();

    Report& report = Report::getInstance();

    Transaction& transaction = Transaction::getInstance();
    transaction.performTransaction();

    Account& account = Account::getInstance();
    account.deposit(1000.0);
    account.withdraw(500.0);

    Loan& loan = Loan::getInstance();
    loan.apply();
    loan.repay(200.0);

    Statement& statement = Statement::getInstance();
    statement.generateStatement();

    Support& support = Support::getInstance();
    support.contactSupport();

    return 0;
}

